package com.icici.ribnli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJwtSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
